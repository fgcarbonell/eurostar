<!-- Vista de la página de resultados -->
<div style="display:block;text-align: center;">
<div style="display:inline-block;">
	<?php echo $__env->make('includes/currentweather', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<div style="display:inline-block;">
		<?php echo $__env->make('includes/formu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>
<div style="display:block;text-align: center;">
	<?php echo $__env->make('includes/busquedas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
