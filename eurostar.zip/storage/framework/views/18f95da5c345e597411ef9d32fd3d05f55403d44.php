<!-- Vista del buscador en la página de resultados -->
<h3>Buscar una ciudad</h3>
<?php echo e(Form::open(['route' => 'Busqueda', 'method' => 'GET', 'role' => 'form'])); ?>

	<?php echo e(Form::text('ciudad', null, ['placeholder'=>'Ingrese una ciudad'])); ?>

	       <p>
	           <input type="submit" value="Enviar" class="btn btn-success">
	       </p> 
<?php echo e(Form::close()); ?>

