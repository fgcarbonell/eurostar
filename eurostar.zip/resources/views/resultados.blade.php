<!-- Vista de la página de resultados -->
<div style="display:block;text-align: center;">
<div style="display:inline-block;">
	@include ('includes/currentweather')
</div>
<div style="display:inline-block;">
		@include('includes/formu')
</div>
</div>
<div style="display:block;text-align: center;">
	@include('includes/busquedas')
</div>
